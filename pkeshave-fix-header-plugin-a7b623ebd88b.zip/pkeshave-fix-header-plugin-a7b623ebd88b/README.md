# README #

Fix header is plugin for fixing the header on scroll
fixHeader plugin is developed by prince keshave
Author URL: coderweb.me
 
### What is this repository for? ###

* For fixing the header on top while scrolling
* 1.0

### How do I get set up? ###

* Configuration
Simply Include the min.js file in your project

```
#!js


<script src="path/fixheader.min.js">
```

**
* How to run tests

```
#!javascript


$('header').fixHeader({
scrollTo:200,
});
```

**
Default option
scrollTo:100 

scrollTo : replace the value to header show when window scroll to your inserted value 




### Contribution guidelines ###

* Writing tests **------ Prince keshave**
* Code review  **------ Prince keshave**


### Who do I talk to? ###

* Repo owner or admin  **------ Prince keshave**
* Other community or team contact  **------ princekeshave.bgp@gmail.com, URL www.coderweb.me**